effects.expectreg <-
function (object, ...) 
{
    object$values
}

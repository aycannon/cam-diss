eexp <-
function (asy, rate = 1) 
{
    egamma(asy, shape = 1, rate = rate)
}

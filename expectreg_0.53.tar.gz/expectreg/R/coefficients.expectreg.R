coefficients.expectreg <-
function (object, ...) 
{
    object$coefficients
}

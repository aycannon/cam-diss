coef.expectreg <-
function (object, ...) 
{
    object$coefficients
}

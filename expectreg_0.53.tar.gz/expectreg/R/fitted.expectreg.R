fitted.expectreg <-
function (object, ...) 
{
    object$fitted
}

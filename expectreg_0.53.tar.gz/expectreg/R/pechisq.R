pechisq <-
function (e, df) 
{
    pegamma(e, shape = df/2, rate = 0.5)
}

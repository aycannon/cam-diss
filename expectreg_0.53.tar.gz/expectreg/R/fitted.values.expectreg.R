fitted.values.expectreg <-
function (object, ...) 
{
    object$fitted
}

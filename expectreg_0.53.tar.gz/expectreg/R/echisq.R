echisq <-
function (asy, df) 
{
    egamma(asy, shape = df/2, rate = 0.5)
}

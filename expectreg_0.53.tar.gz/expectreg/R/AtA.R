AtA <-
function(A) {
    .Call('expectreg_AtA', PACKAGE = 'expectreg', A)
}

AAt <-
function(A) {
    .Call('expectreg_AAt', PACKAGE = 'expectreg', A)
}

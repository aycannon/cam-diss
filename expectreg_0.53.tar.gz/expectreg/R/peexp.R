peexp <-
function (e, rate = 1) 
{
    pegamma(e, shape = 1, rate = rate)
}
